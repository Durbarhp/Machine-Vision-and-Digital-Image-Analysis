% Define the path to the RawImages folder
raw_images_directory = 'C:\Users\HP\Downloads\E5\RawImages';

% Define the path to the Masks folder
masks_directory = 'C:\Users\HP\Downloads\E5\Masks';

% Read frames from the RawImages directory
frames = read_frames_from_directory(raw_images_directory);

% Generate foreground masks using the frame differencing method
foreground_masks = generate_foreground_masks(frames);

% Choose the index of the frame and mask to display
index_to_display = 50; % Choose any index within the range of the number of frames

% Display the chosen frame and its corresponding foreground mask
figure;
subplot(1, 2, 1);
imshow(frames{index_to_display});
title('Original Frame');

subplot(1, 2, 2);
imshow(foreground_masks{index_to_display});
title('Foreground Mask');

% Function to read frames from a directory
function frames = read_frames_from_directory(directory)
    file_pattern = fullfile(directory, '*.bmp');
    bmp_files = dir(file_pattern);
    frames = cell(1, length(bmp_files));
    for k = 1:length(bmp_files)
        base_file_name = bmp_files(k).name;
        full_file_name = fullfile(directory, base_file_name);
        frames{k} = imread(full_file_name);
    end
end

% Function to compute frame differences and generate foreground masks
function foreground_masks = generate_foreground_masks(frames)
    num_frames = length(frames);
    foreground_masks = cell(1, num_frames-1);
    for i = 1:num_frames - 1
        % Compute absolute difference between consecutive frames
        frame_diff = abs(double(frames{i}) - double(frames{i+1}));
        
        % Convert to grayscale
        frame_diff_gray = rgb2gray(uint8(frame_diff));
        
        % Apply thresholding to obtain binary mask
        threshold = 30; % Adjust threshold as needed
        mask = frame_diff_gray > threshold;
        
        % Apply morphology to refine the mask
        se = strel('disk', 3); % Define structuring element
        mask = imclose(mask, se); % Close operation
        mask = imfill(mask, 'holes'); % Fill holes
        
        % Convert to uint8
        mask = uint8(mask) * 255;
        
        % Store the mask
        foreground_masks{i} = mask;
    end
end
