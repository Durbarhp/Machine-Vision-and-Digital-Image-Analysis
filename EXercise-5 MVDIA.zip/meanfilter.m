% Path to RawImages folder
rawImagesDir = 'C:\Users\HP\Downloads\E5\RawImages';

% Read a single frame
frames = readFrames(rawImagesDir, 1); % Read only the first frame

% Apply mean filtering method to the single frame
foregroundMaskMean = meanFilteringMethod(frames{1});

% Display the original frame and its corresponding foreground mask (mean filtering)
figure;
subplot(1, 2, 1);
imshow(frames{1});
title('Original Frame');

subplot(1, 2, 2);
imshow(foregroundMaskMean);
title('Foreground Mask (Mean Filtering)');

% Function to read frames from a directory
function frames = readFrames(directory, numFrames)
    filePattern = fullfile(directory, '*.bmp');
    bmpFiles = dir(filePattern);
    frames = cell(1, numFrames);
    for k = 1:numFrames
        baseFileName = bmpFiles(k).name;
        fullFileName = fullfile(directory, baseFileName);
        frames{k} = imread(fullFileName);
    end
end

% Function to apply mean filtering method
function foregroundMask = meanFilteringMethod(frame)
    % Apply mean filtering to the single frame
    % You can adjust the filter size as needed
    foregroundMask = imgaussfilt(frame, 3);
end
