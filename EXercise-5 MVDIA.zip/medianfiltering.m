% Path to RawImages folder
rawImagesDir = 'C:\Users\HP\Downloads\E5\RawImages';

% Read a single frame
frames = readFrames(rawImagesDir, 1); % Read only the first frame

% Convert the frame to grayscale
grayFrame = rgb2gray(frames{1});

% Apply median filtering to the grayscale frame
medianFilteredFrame = medianFilter(grayFrame);

% Display the original frame and the median filtered image
subplot(1, 2, 1);
imshow(frames{1});
title('Original Frame');

subplot(1, 2, 2);
imshow(medianFilteredFrame);
title('Median Filtered Image');

% Function to read frames from a directory
function frames = readFrames(directory, numFrames)
    filePattern = fullfile(directory, '*.bmp');
    bmpFiles = dir(filePattern);
    frames = cell(1, numFrames);
    for k = 1:numFrames
        baseFileName = bmpFiles(k).name;
        fullFileName = fullfile(directory, baseFileName);
        frames{k} = imread(fullFileName);
    end
end

% Function to apply median filtering to a grayscale frame
function filteredFrame = medianFilter(frame)
    % Apply median filtering with a 3x3 kernel
    filteredFrame = medfilt2(frame, [3, 3]);
end
