% Define the directory paths
rawImagesDir = 'C:\Users\HP\Downloads\E5\RawImages';

% Read frames from the RawImages directory
frames = readFrames(rawImagesDir);

% Generate foreground masks using Gaussian Mixture Model
foregroundMasksGMM = gaussianMixtureModel(frames);

% Choose the frame index to display (e.g., 50)
frameIndex = 50;

% Display the original frame and its foreground mask
figure;

% Original Frame
subplot(1, 2, 1);
imshow(frames{frameIndex});
title('Original Frame');

% Foreground Mask (Gaussian Mixture Model)
subplot(1, 2, 2);
imshow(foregroundMasksGMM{frameIndex});
title('Foreground Mask (GMM)');

% Function to read frames from a directory
function frames = readFrames(directory)
    filePattern = fullfile(directory, '*.bmp');
    bmpFiles = dir(filePattern);
    frames = cell(1, length(bmpFiles));
    for k = 1:length(bmpFiles)
        baseFileName = bmpFiles(k).name;
        fullFileName = fullfile(directory, baseFileName);
        frames{k} = imread(fullFileName);
    end
end

% Function to apply Gaussian Mixture Model for foreground detection
function foregroundMasks = gaussianMixtureModel(frames)
    % Initialize an empty list to store foreground masks
    foregroundMasks = cell(1, length(frames));
    
    % Iterate through frames
    for i = 1:length(frames)
        % Convert frame to grayscale
        frameGray = rgb2gray(frames{i});
        
        % Create foreground detector
        fgDetector = vision.ForegroundDetector(...
            'NumTrainingFrames', 5, ...
            'InitialVariance', 30*30);
        
        % Perform foreground detection
        mask = step(fgDetector, frameGray);
        
        % Apply morphology to refine the mask
        se = strel('disk', 3); % Define structuring element
        mask = imclose(mask, se); % Close operation
        mask = imfill(mask, 'holes'); % Fill holes
        
        % Convert to uint8
        mask = uint8(mask) * 255;
        
        % Store the mask
        foregroundMasks{i} = mask;
    end
end
